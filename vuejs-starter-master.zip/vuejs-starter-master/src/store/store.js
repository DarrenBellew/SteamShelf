const state = {
    version: require('../../package.json').version,
    user: {
        roles: {},
        role: 'ADMIN'
    }
}

export default {
    state,
}